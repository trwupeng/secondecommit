<?php


define('UC_CONNECT', 'mysql');

define('UC_DBHOST', '127.0.0.1');
define('UC_DBUSER', 'root');
define('UC_DBPW', 'Xiaoxia!@#$');
define('UC_DBNAME', 'kkdbbs');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`kkdbbs`.pre_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'lfF5l0i7Xbh3m8o66em9x11cba8b4clbUflfi856q41fM073L3v2N5rdp3Le14X0');
define('UC_API', 'http://ibbs.kuaikuaidai.com/uc_server');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);
?>