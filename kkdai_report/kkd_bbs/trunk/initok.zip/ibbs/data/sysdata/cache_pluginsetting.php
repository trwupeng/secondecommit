<?php
//Discuz! cache file, DO NOT modify me!
//Identify: f31c251ca51a079ca04a8238c9cbf999

$pluginsetting = array (
);
?>