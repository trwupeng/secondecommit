<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 9e6760ab2b2963bcb5008e226a69db95

$adminextend = array (
  0 => 'cloud.php',
);
?>