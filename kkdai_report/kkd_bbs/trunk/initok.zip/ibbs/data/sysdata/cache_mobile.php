<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 784814518849d413ac5bbecfa74ee637

$mobilecheck = '{"discuzversion":"X3.2","charset":"utf-8","version":"4","pluginversion":"1.4.7","oemversion":"0","regname":"register","qqconnect":"0","sitename":"KKD BBS","mysiteid":"","ucenterurl":"http:\\/\\/ibbs.kuaikuaidai.com\\/uc_server","setting":{"closeforumorderby":null},"extends":{"used":null,"lastupdate":null}}';
?>